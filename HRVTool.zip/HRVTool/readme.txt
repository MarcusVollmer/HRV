Readme of the HRVTool v0.92

The present functions are made for Matlab R2015a. Errors may occur using older releases (at least R2014b required).
Please run HRVTool.m to start the GUI (Graphical User Interface).
The user interface has been tested on Windows 7 64bit and Mac OS 10.9.

Polar hrm files are supported.
mat files containing waveforms or RR intervals (in ms) are supported.

Other formats are possible to load. Please write an email to marcus.vollmer@uni-greifswald.de


This work and all supported files and functions are licensed under the terms of the MIT License (MIT)
Copyright (c) 2015 Marcus Vollmer

03 june 2015