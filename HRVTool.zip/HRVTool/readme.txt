Readme of the HRVTool v0.91

The present functions are made for Matlab R2015a.
Please open Matlab and start the GUI (Graphical User Interface) by typing "HRVTool" in the command line.
The user interface was tested on Windows 7 64bit and Mac OS 10.9.


This work and all supported files and functions are licensed under the terms of the MIT License (MIT)
Copyright (c) 2015 Marcus Vollmer

29 may 2015