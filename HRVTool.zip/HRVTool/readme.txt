Readme of the HRVTool v0.91

The present functions are made for Matlab R2015a. Errors may occur using older releases.
Please run HRVTool.m to start the GUI (Graphical User Interface).
The user interface has been tested on Windows 7 64bit and Mac OS 10.9.


This work and all supported files and functions are licensed under the terms of the MIT License (MIT)
Copyright (c) 2015 Marcus Vollmer

02 june 2015